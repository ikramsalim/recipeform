import React, {Component} from 'react';

class Recipe extends Component{
    constructor() {
            super();
            this.state = {
              displayName: '',
              email: '',
              passOne: '',
              passTwo: ''
            };
        
            this.handleChange = this.handleChange.bind(this);
          }
        
          handleChange(e) {
            const itemName = e.target.name;
            const itemValue = e.target.value;
        
            this.setState({ [itemName]: itemValue });
          }
       
         
          

    render(){
        

        const biggerLead ={
            fontSize:2.5 + 'em',
            fontWeight:200

        };
        return (


       
        <div className="container text-center">
        <div className="row justify-content-center">
          <div className="col-10 col-md-10 col-lg-8 col-xl-7">
            <div className="display-4 text-primary mt-3 mb-2"
               style={{
                   fontSize:2.5 + 'em'
                   
                   
               }}
            >
              Create Recipe
            </div>
            
            <a
              href="/choosefile"
              className="btn btn-outline-primary mr-2"
            >
              Choose File
            </a>
            
  

            <form>

            <div className="container">
           <div className="row justify-content-center">
           <div className="col-lg-8">
              <div className="card bg-light">
                <div className="card-body">
                 <h3 className="font-weight-light mb-3">Register</h3>
                 <div className="form-row">

                    {/* Recipe Title */}
                   <section className="col-sm-12 form-group">
                     <label
                       className="form-control-label sr-only"
                      htmlFor="displayName"
                     >
                      Recipe Title
                   </label>
                     <input
                    className="form-control"
                         type="text"
                        id="displayName"
                         placeholder="Recipe Title"
                       name="displayName"
                        required
                        value={this.state.displayName}
                       onChange={this.handleChange}
                     />
                     </section>
                  </div>

                  {/* Book Title */}

                  <div className="form-row">
                  <section className="col-sm-12 form-group">
                     <label
                       className="form-control-label sr-only"
                      htmlFor="displayName"
                     >
                      Book Title
                   </label>
                     <input
                    className="form-control"
                         type="text"
                        id="displayName"
                         placeholder="Book Title"
                       name="displayName"
                        required
                        value={this.state.displayName}
                       onChange={this.handleChange}
                     />
                     </section>
                  </div>

                  {/* Author */}
                  <div className="form-row">
                  <section className="col-sm-12 form-group">
                     <label
                       className="form-control-label sr-only"
                      htmlFor="displayName"
                     >
                      Author
                   </label>
                     <input
                    className="form-control"
                         type="text"
                        id="displayName"
                         placeholder="Author"
                       name="displayName"
                        required
                        value={this.state.displayName}
                       onChange={this.handleChange}
                     />
                     </section>
                  </div>

                  {/* Description */}
                  <div className="form-row">
                  <section className="col-sm-12 form-group">
                     <label
                       className="form-control-label sr-only"
                      htmlFor="displayName"
                     >
                      Description
                   </label>
                     <textarea rows="5" cols="80"
                    className="form-control"
                         type="text "
                        id="displayName"
                         placeholder="Description"
                       name="displayName"
                        required
                        value={this.state.displayName}
                       onChange={this.handleChange}
                     />
                     </section>


                  </div>

                  <div className="display-4 text-primary mt-3 mb-2"
                   style={{
                   fontSize:1.1 + 'em'
                   
                   
                  }}
                    >
                    Ingredients
                </div>



                 <div className="form-row">
                  
                 
                  <section className="col-sm-6 form-group">
                  <form onSubmit={this.handleSubmit}>
                  <label>
                    Quantity UofM
                    <select value={this.state.value} onChange={this.handleChange}>
                            <option value="grapefruit">lbs</option>
                            <option value="lime">g</option>
                            <option value="coconut">kg</option>
                            <option value="mango">cups</option>
                            <option value="grapefruit">lbs</option>
                            <option value="lime">g</option>
                            <option value="coconut">kg</option>
                            <option value="mango">cups</option>
                    </select>
                    </label> 
                    </form>
                  </section>
                           
                           <section className="col-sm-3 form-group">
                            <label>
                            <input
                            name="numberOfGuests"
                            type="number"
                            value={this.state.numberOfGuests}
                            onChange={this.handleInputChange} />
                           </label>   
                           
                          </section>
                         
                

                </div>


                  
                <div className="display-4 text-primary mt-3 mb-2"
                   style={{
                   fontSize:1.1 + 'em'
                   
                   
                  }}
                    >
                    Instructions
                </div>
               
                  


                 <section className="form-group">
                 <label
                     className="form-control-label sr-only"
                     htmlFor="email"
                >
                      Email
                  </label>
                    <input
                    className="form-control"
                     type="email"
                    id="email"
                       placeholder="Email Address"
                    required
                       name="email"
                      value={this.state.email}
                       onChange={this.handleChange}
                     />
                    </section>





                   <div className="form-row">
                     <section className="col-sm-6 form-group">
                       <input
                         className="form-control"
                         type="password"
                         name="passOne"
                         placeholder="Password"
                        value={this.state.passOne}
                         onChange={this.handleChange}
                      />
                     </section>


                     <section className="col-sm-6 form-group">
                       <input
                         className="form-control"
                        type="password"
                         required
                        name="passTwo"
                         placeholder="Repeat Password"
                         value={this.state.passTwo}
                         onChange={this.handleChange}
                       />
                     </section>
                   </div>




                   <div className="form-group text-right mb-0">
                     <button className="btn btn-primary" type="submit">
                      Create Recipe
                     </button>



                   </div>
                 </div>
               </div>
             </div>
          </div>
         </div>
         


            </form>








            {/* <p className="lead" style={biggerLead}>
              This simple app creates meetings, allows people to check
              in, and picks random users to award giveaways. It's a
              good example of a Single Page Application which includes
              connection to a database and routing. It's a practical
              way to learn <a href="https://reactjs.org/">React</a>
              with <a href="https://firebase.google.com">Firebase</a>.
            </p> */}

            {/* <a href="/login" className="btn btn-outline-primary mr-2">
              Log In
            </a>
            <a href="/meetings" className="btn btn-primary">
              Meetings
            </a> */}
          </div>{' '}
          {/* columns */}
        </div>
      </div>
       )
    }
}
export default Recipe;
