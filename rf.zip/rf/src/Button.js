import React, { Component } from 'react';
//create button component
class Button extends React.Component{
    handleClick = () =>{
      this.props.onClickFunction(this.props.increamentValue);
    };
     render(){
       return (
           <button onClick={this.handleClick}>
           +{this.props.increamentValue}
           </button>
       );
     }
  };
  //create result 
const Result = (props) => {
    return(
        <div>{ props.counter }</div>
     )
 };
 
  export default Button;
