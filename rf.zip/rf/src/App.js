// Import React
import React, { Component } from 'react';
import Recipe from './Recipe';
import Welcome from './Welcome';
import Navigation from './Navigation';
import Button from './Button';
//import RecipeForm from './RecipeForm';
//import {Router} from '@reach/router';

import 'bootstrap/dist/css/bootstrap.css';



class App extends Component {

  constructor(){
    super();
    this.state ={
      user: ''
    };

  }
 

  render() {
      return (
    <div>
      <Navigation/>
      <Welcome/>
      <Recipe />
      

     
     
      </div>
    );
  }
}

export default App;